import { useState } from "react";
import { useRouter } from "next/router";

export default function Home() {
  const [name, setName] = useState("");
  const [gender, setGender] = useState("male");
  const router = useRouter();

  const enter = () => {
    router.push(`/room/main?name=${name}&gender=${gender}`);
  };

  return (
    <div style={{ background: 'black', color: 'white', height:'100vh', padding:20 }}>
      <h1>WAVY - Entrance</h1>
      <input placeholder="닉네임" onChange={e=>setName(e.target.value)} />
      <br /><br />
      <select onChange={e=>setGender(e.target.value)}>
        <option value="male">남자</option>
        <option value="female">여자</option>
      </select>
      <br /><br />
      <button onClick={enter}>입장하기</button>
    </div>
  );
}
