import { useEffect, useState } from "react";
import { db } from "../../lib/firebase";
import { ref, set, onValue, push } from "firebase/database";
import { useRouter } from "next/router";

export default function RoomMain() {
  const router = useRouter();
  const { name, gender } = router.query;
  const [table, setTable] = useState(null);
  const [round, setRound] = useState(1);

  useEffect(() => {
    if (!name) return;
    const userRef = push(ref(db, "participants"));
    set(userRef, { name, gender });

    const roundRef = ref(db, "currentRound");
    onValue(roundRef, snap => setRound(snap.val() || 1));

    const tableRef = ref(db, `assignments/${name}`);
    onValue(tableRef, snap => setTable(snap.val()));
  }, [name]);

  return (
    <div style={{ background:'black', color:'white', height:'100vh', padding:20 }}>
      <h1>WAVY ROOM</h1>
      <p>닉네임: {name}</p>
      <p>라운드: {round}</p>
      <p>배정된 테이블: {table ? table : "대기중..."}</p>
    </div>
  );
}
