import { useEffect, useState } from "react";
import { db } from "../../lib/firebase";
import { ref, onValue, set } from "firebase/database";

export default function AdminMain() {
  const [round, setRound] = useState(1);
  const [participants, setParticipants] = useState([]);

  useEffect(() => {
    onValue(ref(db, "participants"), snap => {
      const val = snap.val() || {};
      setParticipants(Object.values(val));
    });
    onValue(ref(db, "currentRound"), snap => {
      setRound(snap.val() || 1);
    });
  }, []);

  const nextRound = () => {
    set(ref(db, "currentRound"), round + 1);
  };

  return (
    <div style={{ background:'black', color:'white', height:'100vh', padding:20 }}>
      <h1>관리자 페이지</h1>
      <p>현재 라운드: {round}</p>
      <button onClick={nextRound}>라운드 증가</button>
      <h3>참가자 목록</h3>
      {participants.map((p,i)=><div key={i}>{p.name} / {p.gender}</div>)}
    </div>
  );
}
