const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

exports.rotate = functions.pubsub.schedule("every 10 minutes").onRun(async () => {
  const db = admin.database();

  const participantsSnap = await db.ref("participants").once("value");
  const participants = participantsSnap.val() || {};

  const male = [];
  const female = [];

  Object.values(participants).forEach(p => {
    if (p.gender === "male") male.push(p);
    else female.push(p);
  });

  male.sort(() => Math.random() - 0.5);
  female.sort(() => Math.random() - 0.5);

  const tables = {};
  for (let i = 0; i < 5; i++) {
    tables[`table_${i+1}`] = {
      male: male.slice(i*2, i*2+2),
      female: female.slice(i*2, i*2+2)
    };
  }

  await db.ref("tableAssignments").set(tables);

  Object.values(participants).forEach(async (p) => {
    for (let t = 1; t <= 5; t++) {
      const group = tables[`table_${t}`];
      const all = [...group.male, ...group.female];
      if (all.find(x => x && x.name === p.name)) {
        await db.ref(`assignments/${p.name}`).set(t);
      }
    }
  });

  const roundRef = await db.ref("currentRound").once("value");
  const currentRound = roundRef.val() || 1;
  await db.ref("currentRound").set(currentRound + 1);

  return null;
});
